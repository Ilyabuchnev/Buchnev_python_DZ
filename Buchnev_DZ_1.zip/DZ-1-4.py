# Задача 4
a = int(input('Введите положительное число'))
x = 0
while a > 0:
   if a > x:
    x = a%10
    a = x-(a%10)
    print(x)
