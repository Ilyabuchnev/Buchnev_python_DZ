#Задача 3
a = input('Введите число ')
b = int(a) + int(a)**2 + int(a)**3
print(b)
