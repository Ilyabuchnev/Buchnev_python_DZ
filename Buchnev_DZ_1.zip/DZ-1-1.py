# Задача 1
a = 10
print(a)
b = 20
print(b)
c = a + b
print(c)
address1 = input('Введите адрес. Город: ')
address2 = input('Улица: ')
address3 = input('номер дома: ')
print(address1 + ', ' + address2 + ', ' + address3 + '.')
